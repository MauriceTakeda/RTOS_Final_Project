/*
 * angle.h
 *
 *  Created on: Sep 10, 2021
 *      Author: mauri
 */

#ifndef SRC_HEADER_FILES_ANGLE_H_
#define SRC_HEADER_FILES_ANGLE_H_

#include "gpio.h"

#define ANGLE_TASK_STACK_SIZE      512

#define ANGLE_TASK_PRIO            29

enum position {
  none = -1,
  farLeft,
  left,
  right,
  farRight,
};

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Structure which holds the vehicle direction data
//----------------------------------------------------------------------------------------------------------------------------------
typedef struct angle_s {

    // current angle
    double angle;

    double angle_prev;
} angle_t;

void angle_init(void);

#endif /* SRC_HEADER_FILES_ANGLE_H_ */
