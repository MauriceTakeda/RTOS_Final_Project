/*
 * physics.h
 *
 *  Created on: Oct 24, 2021
 *      Author: mauri
 */

#ifndef SRC_HEADER_FILES_PHYSICS_H_
#define SRC_HEADER_FILES_PHYSICS_H_

#include "gpio.h"

#define PHYSICS_TASK_STACK_SIZE                  512

#define PHYSICS_TASK_PRIO                        26

enum options {
  OPTION_A, // Capsense slider adjusts angle of attack, buttons control fuel burn rate (+/-)
  OPTION_B, // Capsense slider adjusts angle of attack, buttons burst fuel while held (one button: nominal thrust, the other: MAX thrust)
  OPTION_C, // Capsense slider adjusts fuel burn rate, buttons adjust angle of attack in increments when tapped or held.
  OPTION_D, // Capsense slider adjusts fuel burn rate, buttons burst a quanta of rotational rate to the angle of attack in increments when tapped or held.
  OPTION_E, // Etc—come up with your own ideas, and get agreement from instructor.
};

#define PHYSICS_VERSION                       2 // ok
#define PHYSICS_GRAVITY                       1.62 // (m/s^2) this is lunar gravity
#define PHYSICS_MASS_OF_VEHICLE               2000 // (kg)
#define PHYSICS_GRAPHING_LIMITS_XMIN          0
#define PHYSICS_GRAPHING_LIMITS_XMAX          127 // (m)
#define PHYSICS_OPTION                        OPTION_A // ok
#define PHYSICS_INIT_FUEL_MASS                9000 // (kg)
#define PHYSICS_CONVERSION_EFFICIENCY         200 // (N/kg)
#define PHYSICS_MAX_THRUST                    15000 // (N)
#define PHYSICS_MAX_LANDING_SPEED_VERTICAL    13 // (m/s)
#define PHYSICS_MAX_LANDING_SPEED_HORIZONTAL  4 // (m/s)
#define PHYSICS_BLACKOUT_ACCELERATION         1.9 // (m/s^2)
#define PHYSICS_BLACKOUT_DURATION             5000 // (ms)
#define PHYSICS_INIT_VELOCITY_XVEL            0 // (m/s)
#define PHYSICS_INIT_VELOCITY_YVEL            1 // (m/s)
#define PHYSICS_INIT_HORIZONTAL_POSITION      63 // (m)
#define PHYSICS_ANGLE_OF_ATTACK_CHANGE_QUANTA 0.524 // (rad) about 30degrees

typedef struct graph_lim_s {
  uint32_t xmin; // (m)
  uint32_t xmax; // (m)
} graph_lim_t;

typedef struct max_landing_speed_s {
  double vertical; // (m/s)
  double horizontal; // (m/s)
} max_landing_speed_t;

typedef struct blackout_s {
  double acceleration; // (m/s^2)
  uint32_t duration; // (ms)
} blackout_t;

typedef struct velocity_s {
  double xvel; // (m/s)
  double yvel; // (m/s)
} velocity_t;

typedef struct angle_of_atk_s {
  double angle_change_quanta; // (rad)
  double angle_change_rate;   // (rad/s)
} angle_of_atk_t;

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Structure which holds the physics configuration data
//----------------------------------------------------------------------------------------------------------------------------------
typedef struct physics_s {
  uint32_t version;
  double gravity; // (mm/s^2)
  uint32_t mass;    // (kg)
  graph_lim_t graphing_limits;
  uint32_t option;
  uint32_t max_thrust;  // (N)
  uint32_t init_fuel_mass;  // (kg)
  uint32_t conversion_efficiency;  // (N/kg)
  max_landing_speed_t max_landing_speed;
  blackout_t blackout;
  velocity_t init_velocity;
  int init_horizontal_pos; // (mm)
  angle_of_atk_t angle_of_attack;
} physics_t;

enum vehicle_state {
  VEHICLE_STATE_HEALTHY,
  VEHICLE_STATE_BLACKOUT,
  VEHICLE_STATE_CRASHED,
  VEHICLE_STATE_LANDED,
};

// TODO: Create Systick Handler with private variable for msTicks and use to calculate start and end times
// TODO: Init some of these values in beginning of physics task before while loop
typedef struct flight_state_s {
  velocity_t velocity; // (m/s)
  double acceleration; // (m/s^2)
  double thrust; // (N)
  double mass; // (kg)
  double horizontal_position; // (m)
  double vertical_position; // (m)
  double angle; // (rad)
  uint32_t vehicle_state;
  uint32_t time; // (ms)
  uint32_t blackout_time; // (ms)
} flight_state_t;

void physics_init(void);

#endif /* SRC_HEADER_FILES_PHYSICS_H_ */
