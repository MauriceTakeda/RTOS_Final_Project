/*
 * angle.c
 *
 *  Created on: Sep 10, 2021
 *      Author: mauri
 */
#include <stdlib.h>
#include <fuel_control.h>
#include <physics.h>
#include "os.h"
#include "capsense.h"
#include <angle.h>

extern OS_FLAG_GRP Update_Flags;
extern OS_MUTEX Angle_Mutex;
extern angle_t Angle;
extern physics_t Physics;

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[ANGLE_TASK_STACK_SIZE];
static OS_TMR Angle_Timer;
static OS_SEM Angle_Semaphore;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void angle_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

void Angle_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  RTOS_ERR err;
  OSSemPost(&Angle_Semaphore, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 *@brief
 *  Initialize angle task
 ******************************************************************************/
void angle_init(void)
{
  RTOS_ERR err;

  // Create Semaphore for periodic task wakeup
  OSSemCreate(&Angle_Semaphore, "Angle Semaphore", 0, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Timer for periodic task wakeup
  OSTmrCreate(&Angle_Timer, "Angle Timer", 2, 10, OS_OPT_TMR_PERIODIC, &Angle_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Mutex for Angle data structure
  OSMutexCreate(&Angle_Mutex, "Angle Mutex", &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Angle Task
  OSTaskCreate(&tcb,
               "angle task",
               angle_task,
               DEF_NULL,
               ANGLE_TASK_PRIO,
               &stack[0],
               (ANGLE_TASK_STACK_SIZE / 10u),
               ANGLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 *@brief
 *  Angle task
 ******************************************************************************/
static void angle_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    bool post_flag;

    // Initialize hardware owned by task
    GPIO_DriveStrengthSet(CSEN0_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(CSEN0_port, CSEN0_pin, gpioModeInput, CSEN0_default);

    GPIO_DriveStrengthSet(CSEN1_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(CSEN1_port, CSEN1_pin, gpioModeInput, CSEN1_default);

    GPIO_DriveStrengthSet(CSEN2_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(CSEN2_port, CSEN2_pin, gpioModeInput, CSEN2_default);

    GPIO_DriveStrengthSet(CSEN3_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(CSEN3_port, CSEN3_pin, gpioModeInput, CSEN3_default);

    CAPSENSE_Init();

    // Start Angle Timer
    OSTmrStart(&Angle_Timer, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    // Infinite while()
    while (1)
    {
        post_flag = false;

        // Pend on semaphore from periodic timer
        OSSemPend(&Angle_Semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        // Update Angle Data Structure
        OSMutexPend(&Angle_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        CAPSENSE_Sense();

        Angle.angle_prev = Angle.angle;

        if((CAPSENSE_getPressed(left) || CAPSENSE_getPressed(right)) && !(CAPSENSE_getPressed(farRight) || CAPSENSE_getPressed(farLeft)))
            Angle.angle = 0;
        else if(CAPSENSE_getPressed(farLeft) && !(CAPSENSE_getPressed(left) || CAPSENSE_getPressed(farRight) || CAPSENSE_getPressed(right)))
            Angle.angle = -Physics.angle_of_attack.angle_change_quanta;
        else if(CAPSENSE_getPressed(farRight) && !(CAPSENSE_getPressed(right) || CAPSENSE_getPressed(farLeft) || CAPSENSE_getPressed(left)))
            Angle.angle = Physics.angle_of_attack.angle_change_quanta;

        if(Angle.angle != Angle.angle_prev)
            post_flag = true;
        OSMutexPost(&Angle_Mutex, OS_OPT_POST_1, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        if(post_flag) {
            OSFlagPost(&Update_Flags, EVENT_FLAG_UPDATE_ANGLE, OS_OPT_POST_FLAG_SET, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }
}




