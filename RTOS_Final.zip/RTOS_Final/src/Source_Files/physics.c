/*
 * physics.c
 *
 *  Created on: Oct 24, 2021
 *      Author: mauri
 */
#include <stdlib.h>
#include <math.h>
#include "os.h"
#include <fuel_control.h>
#include <angle.h>
#include <physics.h>

extern OS_FLAG_GRP Update_Flags;
extern OS_MUTEX Fuel_Mutex;
extern OS_MUTEX Angle_Mutex;
extern OS_MUTEX Flight_State_Mutex;
extern OS_SEM LCD_Semaphore;
extern OS_SEM LED_Semaphore;
extern fuel_control_t Fuel_Control;
extern angle_t Angle;
extern physics_t Physics;
extern flight_state_t Flight_State;
extern uint32_t score;

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[PHYSICS_TASK_STACK_SIZE];
static OS_TMR Physics_Timer;
static OS_SEM Physics_Semaphore;
static volatile uint64_t msTicks = 0;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void physics_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

void Physics_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  RTOS_ERR err;
  OSSemPost(&Physics_Semaphore, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void SysTick_Handler(void) {
  msTicks++;
}

/***************************************************************************//**
 *@brief
 *  Initialize physics task
 ******************************************************************************/
void physics_init(void)
{
  RTOS_ERR err;

  // Create Semaphore for periodic task wakeup
  OSSemCreate(&Physics_Semaphore, "Physics Semaphore", 0, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Timer for periodic task wakeup
  OSTmrCreate(&Physics_Timer, "Physics Timer", 0, 1, OS_OPT_TMR_PERIODIC, &Physics_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Mutex for Physics data structure
  OSMutexCreate(&Flight_State_Mutex, "Flight State Mutex", &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Physics Task
  OSTaskCreate(&tcb,
               "physics task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &stack[0],
               (PHYSICS_TASK_STACK_SIZE / 10u),
               PHYSICS_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 *@brief
 *  Physics task
 ******************************************************************************/
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    OS_FLAGS event_flags;

    double fuel_burn_rate = 0;
    double angle_of_attack = 0;
    double force_thrust = 0;
    double x_acceleration = 0;
    double y_acceleration = 0;

    // Flight state initial values
    Flight_State.velocity.xvel = Physics.init_velocity.xvel;
    Flight_State.velocity.yvel = Physics.init_velocity.yvel;
    Flight_State.acceleration = 0;
    Flight_State.thrust = 0;
    Flight_State.mass = Physics.mass + Physics.init_fuel_mass;
    Flight_State.horizontal_position = Physics.init_horizontal_pos;
    Flight_State.vertical_position = 12;
    Flight_State.vehicle_state = VEHICLE_STATE_HEALTHY;
    Flight_State.time = 0;
    Flight_State.blackout_time = 0;
    Flight_State.angle = 0;

    // Configure Systick Clock
    if(SysTick_Config(SystemCoreClockGet()/1000)) {
        EFM_ASSERT(true);
    }

    // Start periodic timer
    OSTmrStart(&Physics_Timer, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    // Infinite while()
    while (1)
    {
        // Pend on periodic semaphore
        OSSemPend(&Physics_Semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        // Non-Blocking Pend on update flags from fuel control and angle tasks
        event_flags = OSFlagPend(&Update_Flags,
                                 EVENT_FLAG_UPDATE_ALL,
                                 0,
                                 OS_OPT_PEND_NON_BLOCKING |
                                 OS_OPT_PEND_FLAG_CONSUME |
                                 OS_OPT_PEND_FLAG_SET_ANY,
                                 DEF_NULL,
                                 &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE) || (RTOS_ERR_CODE_GET(err) == RTOS_ERR_WOULD_BLOCK));

        // If fuel update, then store burn rate in local variable
        if(EVENT_FLAG_UPDATE_FUEL & event_flags) {
            OSMutexPend(&Fuel_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            fuel_burn_rate = Fuel_Control.fuel_burn_rate;
            OSMutexPost(&Fuel_Mutex, OS_OPT_POST_1, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }

        // If angle update, then store angle in local variable
        if(EVENT_FLAG_UPDATE_ANGLE & event_flags) {
            OSMutexPend(&Angle_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            angle_of_attack = Angle.angle;
            OSMutexPost(&Angle_Mutex, OS_OPT_POST_1, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }

        if(Flight_State.vehicle_state == VEHICLE_STATE_HEALTHY || Flight_State.vehicle_state == VEHICLE_STATE_BLACKOUT)
        {
            // Pend on Flight State structure and calculate values
            OSMutexPend(&Flight_State_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            // TIME: calculate time since last update
            CORE_DECLARE_IRQ_STATE;
            CORE_ENTER_CRITICAL();
            Flight_State.time = msTicks;
            msTicks = 0;
            CORE_EXIT_CRITICAL();

            // ANGLE: get angle of attack
            Flight_State.angle = angle_of_attack;

            // MASS: calculate mass
            if(Flight_State.mass <= Physics.mass) { // If no fuel left
                Flight_State.mass = Physics.mass;
                fuel_burn_rate = 0;
            }
            else { // If there is fuel to burn
                Flight_State.mass = Flight_State.mass - (fuel_burn_rate / 1000) * Flight_State.time;                                   // mass_curr = mass_prev - fuel_burn_rate * time
            }

            // THRUST: calculate the force of thrust
            force_thrust = Physics.conversion_efficiency * (fuel_burn_rate / 1000) * Flight_State.time;                                // F_Thrust = Conversion Efficiency * Change in Mass
            if(force_thrust > Physics.max_thrust)
                force_thrust = Physics.max_thrust;
            Flight_State.thrust = force_thrust;

            // ACCELERATION: calculate the acceleration (not including gravity)
            Flight_State.acceleration = force_thrust / Flight_State.mass;                                                     // a = F_thrust / mass
            x_acceleration = -(force_thrust * sin(angle_of_attack)) / Flight_State.mass;                                       // a_x = F_thrust_x / mass
            y_acceleration = (Flight_State.mass * Physics.gravity - force_thrust * cos(angle_of_attack)) / Flight_State.mass; // a_y = (F_thrust_y - F_gravity) / mass

            // VELOCITY: calculate x and y components of velocity
            Flight_State.velocity.xvel += (x_acceleration * Flight_State.time) / 1000;                                                 // v_x_f = v_x_i + a_x * t
            Flight_State.velocity.yvel += (y_acceleration * Flight_State.time) / 1000;                                                 // v_y_f = v_y_i + a_y * t

            // POSITION: calculate horizontal and vertical positions
            Flight_State.horizontal_position += (Flight_State.velocity.xvel * Flight_State.time) / 1000;                               // x_f = x_i + v_x * t
            Flight_State.vertical_position += (Flight_State.velocity.yvel * Flight_State.time) / 1000;                                 // y_f = y_i + v_y * t

            // BLACKOUT_TIME: calculate blackout duration
            if(Flight_State.vehicle_state == VEHICLE_STATE_BLACKOUT)
                Flight_State.blackout_time += Flight_State.time;

            // VEHICLE STATE: determine vehicle state
            if(Flight_State.horizontal_position <= Physics.graphing_limits.xmin
                || Flight_State.horizontal_position >= Physics.graphing_limits.xmax)
            {
                Flight_State.vehicle_state = VEHICLE_STATE_CRASHED;
                score = 0;
            }
            else if(Flight_State.vertical_position >= 127
                && (abs(Flight_State.velocity.xvel) > Physics.max_landing_speed.horizontal
                || abs(Flight_State.velocity.yvel) > Physics.max_landing_speed.vertical))
            {
                Flight_State.vehicle_state = VEHICLE_STATE_CRASHED;
                score = 0;
            }
            else if(Flight_State.vertical_position >= 127 && Flight_State.angle != 0)
            {
                Flight_State.vehicle_state = VEHICLE_STATE_CRASHED;
                score = 0;
            }
            else if(Flight_State.vertical_position >= 127 && Flight_State.vehicle_state == VEHICLE_STATE_BLACKOUT) {
                Flight_State.vehicle_state = VEHICLE_STATE_CRASHED;
                score = 0;
            }
            else if(Flight_State.vertical_position >= 127
                && abs(Flight_State.velocity.xvel) <= Physics.max_landing_speed.horizontal
                && abs(Flight_State.velocity.yvel) <= Physics.max_landing_speed.vertical)
            {
                Flight_State.vehicle_state = VEHICLE_STATE_LANDED;
                score++;
            }
            else if(Flight_State.blackout_time >= Physics.blackout.duration) {
                Flight_State.vehicle_state = VEHICLE_STATE_HEALTHY;
                Flight_State.blackout_time = 0;
            }
            else if(Flight_State.acceleration >= Physics.blackout.acceleration || Flight_State.vehicle_state == VEHICLE_STATE_BLACKOUT) {
                Flight_State.vehicle_state = VEHICLE_STATE_BLACKOUT;
                Flight_State.thrust = 0;
                fuel_burn_rate = 0;
                force_thrust = 0;
            }
            else {
                Flight_State.vehicle_state = VEHICLE_STATE_HEALTHY;
            }

            OSMutexPost(&Flight_State_Mutex, OS_OPT_POST_1, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        else {
            if(msTicks > 10000) {
                // wait for few seconds then restart game and reinitialize values
                OSMutexPend(&Fuel_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
                Fuel_Control.fuel_burn_rate = 0;
                OSMutexPost(&Fuel_Mutex, OS_OPT_POST_1, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

                OSMutexPend(&Angle_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
                Angle.angle = 0;
                OSMutexPost(&Angle_Mutex, OS_OPT_POST_1, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

                OSMutexPend(&Flight_State_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
                Flight_State.velocity.xvel = Physics.init_velocity.xvel;
                Flight_State.velocity.yvel = Physics.init_velocity.yvel;
                Flight_State.acceleration = 0;
                Flight_State.thrust = 0;
                Flight_State.mass = Physics.mass + Physics.init_fuel_mass;
                Flight_State.horizontal_position = Physics.init_horizontal_pos;
                Flight_State.vertical_position = 12;
                Flight_State.vehicle_state = VEHICLE_STATE_HEALTHY;
                Flight_State.time = 0;
                Flight_State.blackout_time = 0;
                Flight_State.angle = 0;
                OSMutexPost(&Flight_State_Mutex, OS_OPT_POST_1, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

                msTicks = 0;
            }
        }

        // Post to LCD and LED tasks
        OSSemPost(&LCD_Semaphore, OS_OPT_POST_1, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        OSSemPost(&LED_Semaphore, OS_OPT_POST_1, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}
