/*
 * led.c
 *
 *  Created on: Sep 10, 2021
 *      Author: mauri
 */

#include <math.h>
#include <led_output.h>
#include <physics.h>
#include "os.h"

extern OS_SEM LED_Semaphore;
extern OS_MUTEX Flight_State_Mutex;
extern physics_t Physics;
extern flight_state_t Flight_State;
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[LED_OUTPUT_TASK_STACK_SIZE];
static OS_TMR LED1_ON_Timer, LED1_OFF_Timer, LED0_ON_Timer, LED0_OFF_Timer;
static uint32_t vehicle_state = VEHICLE_STATE_HEALTHY;
static double acceleration = 0;
static double thrust = 0;
static double led0_pwm = 0;
static double led1_pwm = 0;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void led_output_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

void LED0_ON_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  RTOS_ERR err;
  if(vehicle_state == VEHICLE_STATE_CRASHED)
      GPIO_PinOutClear(LED0_port, LED0_pin);
  else
      GPIO_PinOutSet(LED0_port, LED0_pin);
  if(led0_pwm > 0 && vehicle_state != VEHICLE_STATE_CRASHED) {
      OSTmrStart(&LED0_OFF_Timer, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }
}

void LED0_OFF_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  GPIO_PinOutClear(LED0_port, LED0_pin);
}

void LED1_ON_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  RTOS_ERR err;

  switch(vehicle_state) {
    case VEHICLE_STATE_HEALTHY:
      GPIO_PinOutSet(LED1_port, LED1_pin);
      if(led1_pwm > 0) {
          OSTmrStart(&LED1_OFF_Timer, &err);
          EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
      }
      break;
    case VEHICLE_STATE_BLACKOUT:
    case VEHICLE_STATE_CRASHED:
      GPIO_PinOutToggle(LED1_port, LED1_pin);
      break;
    case VEHICLE_STATE_LANDED:
      GPIO_PinOutClear(LED1_port, LED1_pin);
      break;
    default:
      EFM_ASSERT(true);
      break;
  }
}

void LED1_OFF_TimerCallback(void *p_tmr, void *p_arg) {
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  GPIO_PinOutClear(LED1_port, LED1_pin);
}

/***************************************************************************//**
 *@brief
 *  Initialize LED output task
 ******************************************************************************/
void led_output_init(void)
{
  RTOS_ERR err;

  // Create Semaphore for pend on physics update
  OSSemCreate(&LED_Semaphore, "LED Semaphore", 0, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create LED Timers
  OSTmrCreate(&LED1_ON_Timer, "LED1 ON Timer", 0, 10, OS_OPT_TMR_PERIODIC,
              &LED1_ON_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&LED1_OFF_Timer, "LED1 OFF Timer", 5, 0, OS_OPT_TMR_ONE_SHOT,
              &LED1_OFF_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&LED0_ON_Timer, "LED0 ON Timer", 0, 10, OS_OPT_TMR_PERIODIC,
              &LED0_ON_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTmrCreate(&LED0_OFF_Timer, "LED0 OFF Timer", 5, 0, OS_OPT_TMR_ONE_SHOT,
              &LED0_OFF_TimerCallback, DEF_NULL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create LED Output Task
  OSTaskCreate(&tcb,
               "led output task",
               led_output_task,
               DEF_NULL,
               LED_OUTPUT_TASK_PRIO,
               &stack[0],
               (LED_OUTPUT_TASK_STACK_SIZE / 10u),
               LED_OUTPUT_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 *@brief
 *  LED output task
 ******************************************************************************/
static void led_output_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;

    // Initialize hardware owned by task
    // Set LED ports to be standard output drive with default off (cleared)
    GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

    GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthStrongAlternateStrong);
    GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);

    // Start LED Timers
    OSTmrStart(&LED0_ON_Timer, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    OSTmrStart(&LED1_ON_Timer, &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

    // Infinite while()
    while (1)
    {
        // Pend on Semaphore
        OSSemPend(&LED_Semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        // Get Flight_State Mutex (Vehicle State, Thrust, Acceleration)
        OSMutexPend(&Flight_State_Mutex, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        thrust = Flight_State.thrust;
        acceleration = Flight_State.acceleration;
        vehicle_state = Flight_State.vehicle_state;
        OSMutexPost(&Flight_State_Mutex, OS_OPT_POST_1, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        // Update LED0 PWM
        led0_pwm = (thrust * 10) / Physics.max_thrust;
        if(led0_pwm > 0) {
            OSTmrSet(&LED0_OFF_Timer, (uint32_t)ceil(led0_pwm), 0, &LED0_OFF_TimerCallback, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }

        // Update LED1
        switch(vehicle_state) {
          case VEHICLE_STATE_HEALTHY:
            OSTmrSet(&LED1_ON_Timer, 0, 10, &LED1_ON_TimerCallback, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            led1_pwm = (acceleration * 10) / Physics.blackout.acceleration;
            if(led1_pwm > 0) {
                OSTmrSet(&LED1_OFF_Timer, (uint32_t)ceil(led1_pwm), 0, &LED1_OFF_TimerCallback, DEF_NULL, &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            }
            break;
          case VEHICLE_STATE_BLACKOUT:
            OSTmrSet(&LED1_ON_Timer, 0, 3, &LED1_ON_TimerCallback, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            break;
          case VEHICLE_STATE_CRASHED:
            OSTmrSet(&LED1_ON_Timer, 0, 10, &LED1_ON_TimerCallback, DEF_NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            break;
          case VEHICLE_STATE_LANDED:
            break;
          default:
            EFM_ASSERT(true);
            break;
        }

    }
}
