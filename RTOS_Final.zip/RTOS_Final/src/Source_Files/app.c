/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include <fuel_control.h>
#include <angle.h>
#include <physics.h>
#include <led_output.h>
#include <lcd_display.h>
#include "os.h"
#include "app.h"

// Global Variables
OS_MUTEX Fuel_Mutex;
OS_MUTEX Angle_Mutex;
OS_FLAG_GRP Update_Flags;
OS_MUTEX Flight_State_Mutex;
OS_SEM LCD_Semaphore;
OS_SEM LED_Semaphore;
fuel_control_t Fuel_Control = { .fuel_burn_rate = 0, .dec_count = 0, .inc_count = 0 };
angle_t Angle = { .angle = 0, .angle_prev = 0 };
physics_t Physics = {
    .version               = PHYSICS_VERSION,
    .gravity               = PHYSICS_GRAVITY,
    .mass                  = PHYSICS_MASS_OF_VEHICLE,
    .graphing_limits       = { PHYSICS_GRAPHING_LIMITS_XMIN , PHYSICS_GRAPHING_LIMITS_XMAX},
    .option                = PHYSICS_OPTION,
    .max_thrust            = PHYSICS_MAX_THRUST,
    .init_fuel_mass        = PHYSICS_INIT_FUEL_MASS,
    .conversion_efficiency = PHYSICS_CONVERSION_EFFICIENCY,
    .max_landing_speed     = { PHYSICS_MAX_LANDING_SPEED_VERTICAL , PHYSICS_MAX_LANDING_SPEED_HORIZONTAL },
    .blackout              = { PHYSICS_BLACKOUT_ACCELERATION , PHYSICS_BLACKOUT_DURATION },
    .init_velocity         = { PHYSICS_INIT_VELOCITY_XVEL , PHYSICS_INIT_VELOCITY_YVEL },
    .init_horizontal_pos   = PHYSICS_INIT_HORIZONTAL_POSITION,
    .angle_of_attack       = { PHYSICS_ANGLE_OF_ATTACK_CHANGE_QUANTA, 0 }
};
flight_state_t Flight_State;
uint32_t score = 0;

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
  gpio_open();
  fuel_control_init();
  angle_init();
  physics_init();
  led_output_init();
  lcd_display_init();
}
